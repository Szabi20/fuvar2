[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/vcJQMeKO)
# Fuvar
Mintafeladat a taxi fuvarokról. (2016)

1. A feladat megoldásához hozzon létre grafikus vagy konzolalkalmazást (projektet) Fuvar azonosítóval!
2. Olvassa be a fuvar.csv állományban található adatokat és tárolja el egy megfelelően megválasztott adatszerkezetben! (8 pont)
3. Határozza meg és írja ki a képernyőre a minta szerint, hogy hány utazás került feljegyzésre az állományban! (7 pont)
4. Határozza meg és írja ki a képernyőre a minta szerint, hogy a 6185-ös azonosítójú taxisnak mennyi volt a bevétele, és ez hány fuvarból állt! (7 pont)
5. Programjával határozza meg az állomány adataibó| a fizetési módokat, majd összesítse hogy az egyes fizetési módokat hányszor választották az utak során! (7 pont)
6. Határozza meg és írja ki a képernyőre a minta szerint, hogy összesen hány km-t tettek meg a taxisok (1 mérföld : 1,6 km)! Az eredményt két tizedesjegyre kerekítve jelenítse meg a képernyőn! (7 pont)
7. Határozza meg és írja ki a képernyőre a minta szerint az időben leghosszabb fuvar adatait! Feltételezheti, hogy nem alakult ki holtverseny. (7 pont)
8. Hozzon létre hibak. xt néven egy UTF-8 kódolású szöveges állományt, ami tartalmazza azokat az adatokat, amelyek esetében hiba van az eredeti állományban! (7 pont)
